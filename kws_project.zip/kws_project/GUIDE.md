# Theme 5 – Edge AI & TinyML: complete project guide

**What we built:** a keyword spotter that hears "yes / no / up / down / left / right / on / off / stop / go"
(plus silence and unknown), shrinks to an 8-bit model of about 50 KB, and runs live on a microcontroller,
switching an LED when it hears a command.

```
kws_project/
├── kws_theme5.ipynb      ← Colab notebook: data → train → test → quantise → export (all three tiers)
├── kws_notebook.py       ← same code as a plain script (handy for reading or diffing)
├── kws_live/
│   ├── kws_live.ino      ← Arduino sketch: mic → MFCC → int8 model → LED
│   └── kws_mfcc.h        ← MFCC in C++, a line-by-line port of the notebook's Python
└── GUIDE.md              ← this file
```
The notebook writes two more files into `out/`: **`model_data.h`** and **`kws_config.h`**. Copy them into `kws_live/`.

---

## 1. How to run it (step by step)

### A. The notebook (Foundation + Advanced)
1. Open `kws_theme5.ipynb` in Colab. Runtime → Change runtime type → **T4 GPU** (a CPU also works, just slower).
2. Upload the starter kit: drag the kit **.zip** (or the folder) into the Colab file panel, under `/content`.
3. **Runtime → Run all.** You don't need to edit anything:
   - it unzips the kit, **finds the folder by itself**, and works out the file layout (`.npz`, `.npy`, `.csv` or `.wav` folders)
   - it reads **class names** from the labels (or from a `labels.txt` / `classes.txt` in the kit)
   - it reads the **feature shape** from the data, and **MFCC settings** from any README/config file in the kit
   - if the kit has no validation split, it makes one; if the organisers kept the test labels, it saves `test_predictions.csv` for them
4. Check the printed results:
   - `=== TEST accuracy (float32): xx %  target ≥ 85 %  ✅`  ← **Foundation**
   - `int8 model: xx KB … accuracy drop x.xx points ≤ 2: ✅` ← **Advanced**
5. Take the screenshot of those lines (that's the "results screenshot" deliverable). Download `out/` (right-click → Download).

Optional overrides, all set as environment variables in the first cell (e.g. `os.environ["EPOCHS"]="60"` before the settings code):
`KIT_DIR`, `FEATURE_SOURCE` (`kit`/`wav`), `CHANNELS`, `EPOCHS`, `BATCH`, `SEED`, `TARGET_ACC`, `TARGET_KB`, `TARGET_DROP`,
`TARGET_WORDS` (only for a raw Speech Commands folder layout).

### B. The board (Hard path)
1. Arduino IDE → Boards Manager: install **Arduino Mbed OS Nano Boards** (Nano 33 BLE Sense) or **esp32 by Espressif, v3.x** (ESP32-S3).
2. Library Manager: install the TFLite Micro library **that the kit's sample project uses** (open the sample and check its
   `#include`). If it's unclear: **Chirale_TensorFlowLite** for the Nano, **TensorFlowLite_ESP32** for the ESP32-S3.
3. Copy `out/model_data.h` and `out/kws_config.h` into `kws_live/`, open `kws_live.ino`, select the board/port, Upload.
4. Open the Serial Monitor at **115200**. You should see:
   ```
   MFCC self-test, max difference vs Python: 0.0002x     ← must be below 0.05
   Model 46.6 KB, arena used 2x.x KB
   Listening for: yes no up down left right on off stop go
   >> yes  p=0.93  inference 4x.x ms  features 1.x ms  decision every 60 ms
   ```
5. Demo: say 10 commands about 30 cm from the board. "on" turns the LED on, "off" turns it off, and every other word
   flashes its own colour and blinks the LED.

**ESP32-S3 note:** the defaults suit the XIAO ESP32-S3 Sense on-board PDM mic (CLK 42, DATA 41). For an INMP441 I2S mic,
put `#define ESP_MIC_PDM 0` and your pin numbers at the very top of the sketch.

---

## 2. How it works – explained so you can defend every line

### 2.1 The pipeline
```
mic (16 kHz) → 30 ms frames every 20 ms → Hann window → FFT → power spectrum
            → 40 mel filters → log → DCT → first 10 coefficients = 1 MFCC frame
49 frames (≈1 s) stacked → a 49×10 "image" → normalise → int8 → DS-CNN → 12 probabilities
```

**Why MFCCs?** Raw audio is 16,000 numbers per second, which is too much for a small chip and too detailed.
- The **FFT** shows which frequencies are present in each 30 ms slice.
- The **mel filters** group those frequencies the way the ear does: fine detail at low pitch, coarse at high pitch.
- The **log** matches how we hear loudness, and it turns "louder" into a shift rather than a scaling.
- The **DCT** squeezes the 40 mel values into 10 numbers that describe the overall shape of the spectrum, mainly the shape of the mouth and throat, which is what tells words apart.

So 1 s of audio becomes just 490 numbers.

### 2.2 The network: DS-CNN (Hello Edge, Zhang et al., ARM 2017)
| Layer | Output | Params | Why |
|---|---|---|---|
| Input | 49×10×1 | – | MFCC image |
| Conv 10×4, stride 2, 64 ch + BN + ReLU | 25×5×64 | 2.6 k | sees ~200 ms × 4 coefficients at once; stride halves the work |
| 4 × [Depthwise 3×3 + BN + ReLU → Pointwise 1×1 + BN + ReLU] | 25×5×64 | 4×4.9 k | the "separable" trick |
| Dropout 0.3 | | | against overfitting |
| Global average pool | 64 | | one number per feature map; works for any position of the word |
| Dense + softmax | 12 | 0.8 k | class probabilities |
| **Total** | | **≈ 24 k** | |

(The first-layer kernel size scales with the input shape, so different kit features still work.)

**Depthwise-separable conv, the key idea:** a normal 3×3 conv with 64→64 channels needs 3·3·64·64 = 36,864 weights.
Splitting it into a *depthwise* 3×3 (one filter per channel: 576 weights) and a *pointwise* 1×1 (mixing channels:
4,096 weights) needs only 4,672, which is **about 8× fewer** parameters and multiplies for nearly the same accuracy. That's why MobileNet and every TinyML KWS model use it.

### 2.3 Training choices (what changed from the baseline, and why)
| Change | Why |
|---|---|
| Baseline = 2-layer dense net on the flattened MFCC | a number to beat; it can't handle the word moving in time |
| CNN instead of dense | a word is a time-frequency pattern; convs find it wherever it sits in the clip |
| BatchNorm (momentum 0.9) | faster, steadier training; at export it **folds into the conv weights**, so it's free on the chip |
| Normalise each coefficient with **training-set** mean/std | the test set is never used for anything; the same 10 means/stds are copied to the board |
| Augmentation: ±10 % time shift, time mask, frequency mask (SpecAugment), small noise | people speak early or late and rooms are noisy; augmentation stops it memorising the training speakers |
| Adam + cosine learning-rate decay | big steps early, fine-tuning late |
| Early stopping on **validation** accuracy (restore best epoch) | picks the model without looking at test |
| Separate train / val / test, split **by speaker** | the score measures new voices, not memorised ones |

### 2.4 Quantisation (Advanced tier)
Every float32 weight and activation is mapped to int8: `real ≈ scale × (q − zero_point)`.
- **Weights:** the range is known, so mapping is direct.
- **Activations:** the converter runs about 500 training clips (the *representative dataset*) through the model to find each layer's range.
- Result: **4× smaller** (≈ 97 KB → ≈ 47 KB, well under 250 KB) and fast int8 maths (CMSIS-NN on Cortex-M4, ESP-NN on ESP32-S3).
- The accuracy drop is usually 0–1 point, because each layer's output only needs about 256 distinct levels to make the same decision.
- We export with **batch size 1**, so the model uses only 5 ops (CONV_2D, DEPTHWISE_CONV_2D, AVERAGE_POOL_2D, FULLY_CONNECTED, SOFTMAX) that every TFLM build supports.

### 2.5 On the board (Hard path)
- **Same features as training:** `kws_mfcc.h` is a direct port of the Python `mfcc()`, and every setting comes from `kws_config.h`. At boot the board makes a chirp signal, computes its MFCCs and compares them to Python's values (the self-test line). We checked it on a PC: max difference **0.0002**, and the int8 input the sketch builds is **identical** to Python's (490 of 490 values).
- **Streaming:** the mic fills a ring buffer. Every 20 ms of new audio gives one new MFCC frame, which overwrites the oldest of the 49 (a circular buffer). So each new frame costs about 1–2 ms, rather than recomputing the whole second each time.
- **Decisions every 60 ms:** run the network, average the last 3 outputs (fewer flickers), accept if a keyword's probability is ≥ 0.70, then ignore new detections for 1 s.
- **Latency budget (target 200 ms):** decision interval 60 ms + features about 2 ms + inference ~30–60 ms on a Nano 33 BLE with CMSIS-NN ≈ **100–130 ms** from the end of the word. The Serial line prints the real numbers, so you can show the judges.

---

## 3. The 3 slides (fill the numbers from `out/summary.json`)

**Slide 1 – Problem & tier**
- Theme 5, Edge AI & TinyML. Tier: **Hard path**
- Offline voice commands on a low-cost microcontroller: no internet, no cloud, ~50 KB model
- Targets: ≥ 85 % accuracy · int8 ≤ 250 KB with ≤ 2-point drop · live, 8/10 correct within 200 ms

**Slide 2 – Approach** (diagram: MFCC 49×10 → Conv → 4× DS block → GAP → Dense 12)
- DS-CNN, ≈ 24 k params; baseline was a dense net at `baseline_val_acc` %
- Changes: convs (time-shift invariance), BatchNorm, SpecAugment + shift, early stopping, speaker-separated splits
- Full int8 post-training quantisation → TFLite Micro; on-device MFCC identical to training (self-test 0.0002)
- Libraries: TensorFlow/Keras, TFLite Micro, scikit-learn, CMSIS-NN. No pretrained weights.

**Slide 3 – Result**
- Accuracy `float_acc` % (target 85) · int8 `int8_acc` % at `int8_kb` KB (drop `acc_drop_points`)
- Plot: `out/confusion_matrix.png`
- Failure case: paste the top 2 lines from `out/failure_story.txt` with one image from `out/failure_cases.png`
- Live: X / 10 correct, ~NN ms (from the Serial Monitor)

**Live proof (30 s):** say "on" → LED on, "off" → LED off, then "yes", "stop". Keep the Serial Monitor on screen.
Backup if the board fails: Section 8 of the notebook, `predict_wav()` on a phone recording.

---

## 4. Questions judges will probably ask

- **Why not a bigger model / an LSTM / a transformer?** Their memory and compute don't fit 256 KB of RAM. DS-CNN gives the best accuracy per multiply in published KWS benchmarks (Hello Edge, MLPerf Tiny uses DS-CNN for KWS).
- **Why MFCC and not raw audio?** It cuts 16,000 values to 490 while keeping what tells words apart, and it costs about 1 ms per frame on the chip.
- **How do you know you didn't overfit to test?** Normalisation stats come from train only, early stopping uses validation, the test set is touched once at the end, and splits are by speaker.
- **Why did int8 barely lose accuracy?** Calibration with a representative dataset gives each layer its own scale. BatchNorm folds into the weights. Classification only needs the top class to stay on top.
- **What's "unknown" and why is it hard?** It's 25 other words in one class, so its boundary with real keywords is the fuzziest. That's where many errors are.
- **What would you improve?** Train with recordings made through the board's own mic (mic mismatch is the biggest real-world drop), add background-noise mixing, try quantisation-aware training, and tune the threshold with a false-alarm-per-hour test.
- **Latency – how measured?** `micros()` around feature extraction and `Invoke()`, printed on every detection, plus the 60 ms decision interval.

---

## 5. Troubleshooting

| Symptom | Fix |
|---|---|
| Notebook says "No kit found – using SYNTHETIC data" | Put the kit under `/content` (or set `os.environ["KIT_DIR"]`) and run again |
| Warning that data is A×B but MFCC settings give C×D | The kit uses different MFCC settings. Training is fine; for the board, fill `FEAT` in Section 1 with the kit's real settings (from its README), or retrain with `FEATURE_SOURCE="wav"` if the kit has .wav files |
| Accuracy below 85 % | `EPOCHS=80`, `CHANNELS=96`. Check the class counts are balanced |
| Self-test on the board > 0.05 | The headers came from different runs; re-copy both files from the same `out/` |
| `AllocateTensors failed` | Raise `TENSOR_ARENA_KB` (e.g. 96) |
| Compile error about `MicroInterpreter` arguments | Your TFLM library is older: add `#define TFLM_NEEDS_ERROR_REPORTER 1` at the top |
| Compile error about a missing `Add…()` op | Delete that line from the resolver list (only the 5 ops above are actually needed) |
| Inference > 150 ms | Use a library with CMSIS-NN (Chirale) / ESP-NN, or retrain with `CHANNELS=32` |
| Words not detected | Speak closer, raise `MIC_GAIN`, or lower `DETECT_THRESHOLD` to 0.6 |
| Random false triggers | Raise `DETECT_THRESHOLD` to 0.8 or `AVG_WINDOW` to 4 |
| Live accuracy much worse than notebook | Mic mismatch. If the kit has .wav files, train with `FEATURE_SOURCE="wav"`; record about 20 clips per word on the board and add them |

**Rules reminder:** no training before 14:30, test labels never used for training, and the team must be able to explain every line (that's what Section 2 is for).
