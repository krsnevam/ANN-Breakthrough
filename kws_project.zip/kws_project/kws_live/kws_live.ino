// kws_live.ino – live keyword spotting on a microcontroller (Theme 5 hard path)
//
// Boards: Arduino Nano 33 BLE Sense (built-in PDM mic) or ESP32-S3 (PDM mic, e.g. XIAO ESP32-S3 Sense,
//         or an I2S mic such as the INMP441).
// Files in this folder: kws_live.ino, kws_mfcc.h, plus kws_config.h and model_data.h from the notebook (out/).
//
// How it works: the mic fills a ring buffer → every 20 ms (one hop) we compute one new MFCC frame → we keep the
// last N_FRAMES frames (1 s) → every few frames we run the int8 DS-CNN → average the last few outputs →
// if one keyword clearly wins, switch the LED and print the word with timings over Serial (115200 baud).
//
// Nothing about the model is fixed in this file: labels, MFCC settings, normalisation and quantisation all
// come from kws_config.h, so after retraining you only copy in the two new headers.

// ---------------- TensorFlow Lite Micro library ----------------
// Use the same library as the kit's pre-flashed sample project (open it and check its #include lines).
#if __has_include(<Chirale_TensorFlowLite.h>)
  #include <Chirale_TensorFlowLite.h>          // Library Manager: "Chirale_TensorFlowLite" (Nano 33 BLE etc.)
#elif __has_include(<TensorFlowLite_ESP32.h>)
  #include <TensorFlowLite_ESP32.h>            // Library Manager: "TensorFlowLite_ESP32"
  #define TFLM_NEEDS_ERROR_REPORTER 1          // this older port still takes an ErrorReporter
#elif __has_include(<TensorFlowLite.h>)
  #include <TensorFlowLite.h>                  // older "Arduino_TensorFlowLite"
#endif
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"
#ifdef TFLM_NEEDS_ERROR_REPORTER
  #include "tensorflow/lite/micro/micro_error_reporter.h"
#endif

#include "kws_config.h"
#include "model_data.h"
#include "kws_mfcc.h"

// ---------------- Tunables (behaviour only – nothing model-specific) ----------------
#ifndef INFER_EVERY_FRAMES
#define INFER_EVERY_FRAMES 3        // run the network every 3 new frames (60 ms with a 20 ms hop)
#endif
#ifndef AVG_WINDOW
#define AVG_WINDOW 3                // average this many consecutive outputs (fewer flickers)
#endif
#ifndef DETECT_THRESHOLD
#define DETECT_THRESHOLD 0.70f      // averaged probability needed to accept a keyword
#endif
#ifndef REFRACTORY_MS
#define REFRACTORY_MS 1000          // ignore new detections for this long after one
#endif
#ifndef MIC_GAIN
#define MIC_GAIN 30                 // Nano PDM gain (0–80). Raise it if quiet words aren't picked up
#endif
#ifndef TENSOR_ARENA_KB
#define TENSOR_ARENA_KB 64
#endif
// ESP32-S3 mic wiring (only used on ESP32). Defaults are the XIAO ESP32-S3 Sense on-board PDM mic.
#ifndef ESP_MIC_PDM
#define ESP_MIC_PDM 1               // 1 = PDM mic (CLK, DATA); 0 = I2S mic like INMP441 (SCK, WS, SD)
#endif
#ifndef ESP_PIN_CLK
#define ESP_PIN_CLK 42              // PDM CLK  / I2S SCK
#endif
#ifndef ESP_PIN_WS
#define ESP_PIN_WS -1               // I2S WS (not used for PDM)
#endif
#ifndef ESP_PIN_DATA
#define ESP_PIN_DATA 41             // PDM DATA / I2S SD
#endif

// ---------------- Audio capture: ring buffer filled by the mic ----------------
static const int kRing = 8192;                        // power of two, > 0.5 s of audio
static volatile int16_t g_ring[kRing];
static volatile uint32_t g_write = 0;                  // total samples written (wraps naturally)
static uint32_t g_read = 0;                            // next sample index we haven't framed yet

static inline void push_samples(const int16_t* s, int n) {
  uint32_t w = g_write;
  for (int i = 0; i < n; i++) g_ring[(w + i) & (kRing - 1)] = s[i];
  g_write = w + n;
}

#if defined(ARDUINO_ARCH_MBED) || defined(ARDUINO_ARDUINO_NANO33BLE)
  #include <PDM.h>
  static int16_t g_pdm_buf[512];
  static void on_pdm() {
    int bytes = PDM.available();
    if (bytes > (int)sizeof(g_pdm_buf)) bytes = sizeof(g_pdm_buf);
    PDM.read(g_pdm_buf, bytes);
    push_samples(g_pdm_buf, bytes / 2);
  }
  static bool mic_begin() {
    PDM.onReceive(on_pdm);
    PDM.setBufferSize(sizeof(g_pdm_buf));
    if (!PDM.begin(1, KWS_SR)) return false;
    PDM.setGain(MIC_GAIN);
    return true;
  }
  static void mic_poll() {}                            // interrupt driven
  #define LED_ON_LEVEL LOW                             // Nano RGB LED pins are active-low
  static const int kRgb[3] = {LEDR, LEDG, LEDB};
  static const int kMainLed = LED_BUILTIN; static const int kMainOn = HIGH;
#elif defined(ARDUINO_ARCH_ESP32)
  #include <ESP_I2S.h>                                 // Arduino-ESP32 core 3.x
  static I2SClass g_i2s;
  static bool mic_begin() {
  #if ESP_MIC_PDM
    g_i2s.setPinsPdmRx(ESP_PIN_CLK, ESP_PIN_DATA);
    return g_i2s.begin(I2S_MODE_PDM_RX, KWS_SR, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO);
  #else
    g_i2s.setPins(ESP_PIN_CLK, ESP_PIN_WS, -1, ESP_PIN_DATA);
    return g_i2s.begin(I2S_MODE_STD, KWS_SR, I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_MONO);
  #endif
  }
  static void mic_poll() {                             // pull whatever the DMA has ready
  #if ESP_MIC_PDM
    static int16_t buf[256];
    size_t got = g_i2s.readBytes((char*)buf, sizeof(buf));
    if (got) push_samples(buf, got / 2);
  #else
    static int32_t raw[256]; static int16_t buf[256];
    size_t got = g_i2s.readBytes((char*)raw, sizeof(raw)) / 4;
    for (size_t i = 0; i < got; i++) buf[i] = (int16_t)(raw[i] >> 14);   // 24-bit in 32 → 16-bit, small boost
    if (got) push_samples(buf, got);
  #endif
  }
  #define LED_ON_LEVEL LOW
  static const int kRgb[3] = {-1, -1, -1};             // most ESP32-S3 boards: one LED only
  #ifdef LED_BUILTIN
  static const int kMainLed = LED_BUILTIN;
  #else
  static const int kMainLed = -1;
  #endif
  static const int kMainOn = LOW;                      // XIAO ESP32-S3 user LED is active-low
#else
  #error "Unsupported board: add a mic_begin()/mic_poll() for it"
#endif

// ---------------- Model ----------------
alignas(16) static uint8_t g_arena[TENSOR_ARENA_KB * 1024];
static tflite::MicroInterpreter* g_interp = nullptr;
static TfLiteTensor *g_in = nullptr, *g_out = nullptr;
static kws::Mfcc g_mfcc;

static float g_feat[KWS_N_FRAMES][KWS_N_MFCC];        // circular buffer of MFCC frames
static int g_feat_head = 0;                            // index of the oldest frame
static int g_frames_seen = 0;
static float g_hist[AVG_WINDOW][KWS_NUM_CLASSES];
static int g_hist_n = 0;
static uint32_t g_last_detect = 0;
static bool g_is_background[KWS_NUM_CLASSES];         // silence / unknown style classes
static int g_idx_on = -1, g_idx_off = -1;

static bool name_is(const char* a, const char* b) { return strcmp(a, b) == 0; }

static void classify_labels() {
  for (int i = 0; i < KWS_NUM_CLASSES; i++) {
    const char* n = KWS_LABELS[i];
    g_is_background[i] = n[0] == '_' || strstr(n, "silence") || strstr(n, "unknown") ||
                         strstr(n, "noise") || strstr(n, "background") || strstr(n, "other");
    if (name_is(n, "on")) g_idx_on = i;
    if (name_is(n, "off")) g_idx_off = i;
  }
}

// ---------------- LED feedback ----------------
// "on" turns the main LED on and "off" turns it off. Every other keyword lights an RGB colour picked from its
// class index (on boards with an RGB LED) and blinks the main LED, so every command visibly does something.
static void set_rgb(int code) {                        // code bit0=R bit1=G bit2=B, 0 = all off
  for (int c = 0; c < 3; c++)
    if (kRgb[c] >= 0) digitalWrite(kRgb[c], (code >> c) & 1 ? LED_ON_LEVEL : !LED_ON_LEVEL);
}
static void set_main(bool on) { if (kMainLed >= 0) digitalWrite(kMainLed, on ? kMainOn : !kMainOn); }
static bool g_main_state = false;
static uint32_t g_rgb_off_at = 0, g_blink_until = 0;

static void show(int cls) {
  if (cls == g_idx_on) { g_main_state = true; set_main(true); set_rgb(0b010); }
  else if (cls == g_idx_off) { g_main_state = false; set_main(false); set_rgb(0b001); }
  else { set_rgb(1 + cls % 7); g_blink_until = millis() + 300; set_main(!g_main_state); }
  g_rgb_off_at = millis() + 1500;
}
static void led_tick() {
  uint32_t now = millis();
  if (g_rgb_off_at && now > g_rgb_off_at) { set_rgb(0); g_rgb_off_at = 0; }
  if (g_blink_until && now > g_blink_until) { set_main(g_main_state); g_blink_until = 0; }
}

// ---------------- Setup ----------------
void setup() {
  Serial.begin(115200);
  uint32_t t0 = millis(); while (!Serial && millis() - t0 < 3000) {}
  for (int c = 0; c < 3; c++) if (kRgb[c] >= 0) pinMode(kRgb[c], OUTPUT);
  if (kMainLed >= 0) pinMode(kMainLed, OUTPUT);
  set_rgb(0); set_main(false);

  g_mfcc.begin();
  float err = kws::self_test(g_mfcc);
  Serial.print("MFCC self-test, max difference vs Python: "); Serial.println(err, 5);
  if (err > 0.05f) Serial.println("  !! Features don't match training – re-copy kws_config.h from the same notebook run");

  const tflite::Model* model = tflite::GetModel(g_kws_model);
  if (model->version() != TFLITE_SCHEMA_VERSION) { Serial.println("Model schema mismatch"); while (1) {} }

  // Register a superset of ops so a retrained/changed model still loads
  static tflite::MicroMutableOpResolver<12> resolver;
  resolver.AddConv2D(); resolver.AddDepthwiseConv2D(); resolver.AddAveragePool2D(); resolver.AddMaxPool2D();
  resolver.AddFullyConnected(); resolver.AddSoftmax(); resolver.AddReshape(); resolver.AddMean();
  resolver.AddQuantize(); resolver.AddDequantize(); resolver.AddRelu(); resolver.AddAdd();

#ifdef TFLM_NEEDS_ERROR_REPORTER
  static tflite::MicroErrorReporter reporter;
  static tflite::MicroInterpreter interp(model, resolver, g_arena, sizeof(g_arena), &reporter);
#else
  static tflite::MicroInterpreter interp(model, resolver, g_arena, sizeof(g_arena));
#endif
  g_interp = &interp;
  if (g_interp->AllocateTensors() != kTfLiteOk) {
    Serial.println("AllocateTensors failed – increase TENSOR_ARENA_KB"); while (1) {}
  }
  g_in = g_interp->input(0); g_out = g_interp->output(0);
  Serial.print("Model "); Serial.print(g_kws_model_len / 1024.0f, 1); Serial.print(" KB, arena used ");
  Serial.print(g_interp->arena_used_bytes() / 1024.0f, 1); Serial.println(" KB");

  classify_labels();
  if (!mic_begin()) { Serial.println("Microphone failed to start"); while (1) {} }
  Serial.print("Listening for:");
  for (int i = 0; i < KWS_NUM_CLASSES; i++) if (!g_is_background[i]) { Serial.print(' '); Serial.print(KWS_LABELS[i]); }
  Serial.println();
}

// ---------------- Inference on the last 1 s of features ----------------
static uint32_t g_feat_us = 0;                         // time spent on the latest MFCC frames

static void run_inference() {
  uint32_t t0 = micros();
  int8_t* in = g_in->data.int8;
  for (int f = 0; f < KWS_N_FRAMES; f++) {
    const float* src = g_feat[(g_feat_head + f) % KWS_N_FRAMES];   // oldest → newest
    for (int k = 0; k < KWS_N_MFCC; k++) {
      float x = (src[k] - KWS_MEAN[k]) / KWS_STD[k];               // same normalisation as training
      int q = (int)lroundf(x / KWS_IN_SCALE) + KWS_IN_ZP;          // float → int8
      in[f * KWS_N_MFCC + k] = (int8_t)(q < -128 ? -128 : q > 127 ? 127 : q);
    }
  }
  if (g_interp->Invoke() != kTfLiteOk) { Serial.println("Invoke failed"); return; }
  uint32_t infer_us = micros() - t0;

  float* h = g_hist[g_hist_n % AVG_WINDOW];
  for (int c = 0; c < KWS_NUM_CLASSES; c++) h[c] = (g_out->data.int8[c] - KWS_OUT_ZP) * KWS_OUT_SCALE;
  g_hist_n++;
  int n = g_hist_n < AVG_WINDOW ? g_hist_n : AVG_WINDOW;
  int best = 0; float bestp = -1;
  for (int c = 0; c < KWS_NUM_CLASSES; c++) {
    float s = 0; for (int i = 0; i < n; i++) s += g_hist[i][c];
    s /= n;
    if (s > bestp) { bestp = s; best = c; }
  }
  uint32_t now = millis();
  if (!g_is_background[best] && bestp >= DETECT_THRESHOLD && now - g_last_detect > REFRACTORY_MS) {
    g_last_detect = now;
    show(best);
    Serial.print(">> "); Serial.print(KWS_LABELS[best]);
    Serial.print("  p="); Serial.print(bestp, 2);
    Serial.print("  inference "); Serial.print(infer_us / 1000.0f, 1);
    Serial.print(" ms  features "); Serial.print(g_feat_us / 1000.0f, 1);
    Serial.print(" ms  decision every "); Serial.print(INFER_EVERY_FRAMES * KWS_HOP * 1000 / KWS_SR);
    Serial.println(" ms");
  }
}

// ---------------- Main loop ----------------
void loop() {
  mic_poll();
  led_tick();
  static float frame[KWS_FRAME_LEN];
  // Make a new MFCC frame each time a full hop of new audio has arrived
  while ((int32_t)(g_write - g_read) >= KWS_FRAME_LEN) {
    if (g_write - g_read > (uint32_t)(kRing - KWS_FRAME_LEN)) g_read = g_write - KWS_FRAME_LEN;  // fell behind: skip
    uint32_t t0 = micros();
    for (int n = 0; n < KWS_FRAME_LEN; n++) frame[n] = g_ring[(g_read + n) & (kRing - 1)] / 32768.0f;
    g_mfcc.compute(frame, g_feat[g_feat_head]);       // overwrite the oldest frame…
    g_feat_head = (g_feat_head + 1) % KWS_N_FRAMES;    // …which now becomes the newest
    g_read += KWS_HOP;
    g_feat_us = micros() - t0;
    if (++g_frames_seen >= KWS_N_FRAMES && g_frames_seen % INFER_EVERY_FRAMES == 0) run_inference();
  }
}
